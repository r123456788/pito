This is where the server's start and dependency installation scripts are stored.
To be able to run the server, you must first run Install_Dependencies.bat (or ogar-linux-script.sh if your using linux)
Once they're installed and you should see a node_modules folder outside of this one.
To start the server,
 run Start-windows.bat (or Start-linux.sh if your using linux)



MINEMOORE AND MEGABYTE + NAMEYT ! LOT OF PEOPLE!